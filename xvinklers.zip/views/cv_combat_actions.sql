DROP VIEW IF EXISTS cv_combat_actions;
CREATE OR REPLACE VIEW cv_combat_actions AS
SELECT 
    a.id AS action_id,
    a.actor_id,
    a.spell_id,
    a.target_id,
    a.item_id,
    a.effect,
    a.dice_roll,
    a.ap_cost,
    a.action_type,
    a.action_timestamp,
    a.round_id,
    cr.time_started AS round_start_time,
    cr.time_ended AS round_end_time,
    cr.combat_id
FROM "Actions" AS a
JOIN "CombatRounds" AS cr ON a.round_id = cr.id
ORDER BY cr.combat_id, a.action_timestamp, a.id;

SELECT * FROM cv_combat_actions;

